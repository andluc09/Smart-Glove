package com.example.raul;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class PacienteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cad_pac);
    }
}